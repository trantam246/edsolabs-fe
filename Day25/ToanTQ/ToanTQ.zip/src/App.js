import RouterPage from './routers/RouterPage';

function App() {
  return (
    <div className="App">
      <RouterPage />
    </div>
  );
}

export default App;
