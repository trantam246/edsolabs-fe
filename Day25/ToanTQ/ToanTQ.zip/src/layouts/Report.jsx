import React from 'react';
import { Box, Typography } from '@material-ui/core';

export default function Report() {
  return (
    <Box container>
      <Typography component="h2"> Report</Typography>
    </Box>
  );
}
